﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car_game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            linemove(gamespeed);
            enemy(gamespeed);
            coin(gamespeed);
            coincollect();
            flagc(gamespeed);
             gameover();

            
        }
        int gamespeed = 0;
        void linemove(int speed)
        {
            if (rl1.Top >= 500)
            { rl1.Top = -10; }
            else
            { rl1.Top += speed; }
            if (rl2.Top >= 500)
            { rl2.Top = -10; }
            else
            { rl2.Top += speed; }
            if (rl3.Top >= 500)
            { rl3.Top = -10; }
            else
            { rl3.Top += speed; }
            if (rl4.Top >= 500)
            { rl4.Top = -10; }
            else
            { rl4.Top += speed; }
            if (rl5.Top >= 500)
            { rl5.Top = -10; }
            else
            { rl5.Top += speed; }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                if (car.Left > 15)
                    car.Left += -10;
            }
            if (e.KeyCode == Keys.Right)
            {
                if (car.Right < 315)
                    car.Left += 10;
            }
            if (e.KeyCode == Keys.Up)
            {
                if (gamespeed <= 20)
                    gamespeed++;
            }
            if (e.KeyCode == Keys.Down)
            {
                if (gamespeed > 0)
                    gamespeed--;
            }
        }
        
Random r = new Random();
int x;
void enemy(int speed)
{
   if (enemy1.Top >= 500)
   {
       x = r.Next(155, 280);
       enemy1.Location = new Point(x, 0);
   }
   else
   { enemy1.Top += speed; }
   if (enemy2.Top >= 500)
   {
       x = r.Next(155, 280);
       enemy2.Location = new Point(x, 0);
   }
   else
   { enemy2.Top += speed; }
   if (enemy5.Top >= 500)
   {
       x = r.Next(155, 280);
       enemy5.Location = new Point(x, 0);
   }
   else
   { enemy5.Top += speed; }
   if (enemy3.Top >= 500)
   {
       x = r.Next(0, 145);
       enemy3.Location = new Point(x, 0);
   }
   else
   { enemy3.Top += speed; }

   if (enemy4.Top >= 500)
   {
       x = r.Next(0, 100);
       enemy4.Location = new Point(x, 0);
   }
   else
   { enemy4.Top += speed; }
}
Random r2 = new Random();
int y, z;
void coin(int speed)
{
   if (coin1.Top >= 500)
   {
       y = r2.Next(0, 145);
       z = r2.Next(0, 378);
       coin1.Location = new Point(y, z);
   }
   else
   { coin1.Top += speed; }
   if (coin2.Top >= 500)
   {
       y = r2.Next(0, 145);
       z = r2.Next(0, 378);
       coin2.Location = new Point(y, z);
   }
   else
   { coin2.Top += speed; }
   if (coin3.Top >= 500)
   {
       y = r2.Next(155, 280);
       z = r2.Next(0, 378);
       coin3.Location = new Point(y, z);
   }
   else
   { coin3.Top += speed; }
   if (coin4.Top >= 500)
   {
       y = r2.Next(155, 280);
       z = r2.Next(0, 378);
       coin4.Location = new Point(y, z);
   }
   else
   { coin4.Top += speed; }
}
int coins = 0;
void coincollect()
{
   if (car.Bounds.IntersectsWith(coin1.Bounds))
   {
       coins++;
       coinscol.Text = "Conis=" + coins.ToString();
       y = r2.Next(0, 145);
       z = r2.Next(0, 378);
       coin1.Location = new Point(y, z);
   }
   if (car.Bounds.IntersectsWith(coin2.Bounds))
   {
       coins++;
       coinscol.Text = "Conis=" + coins.ToString();
       y = r2.Next(0, 145);
       z = r2.Next(0, 378);
       coin2.Location = new Point(y, z);
   }
   if (car.Bounds.IntersectsWith(coin3.Bounds))
   {
       coins++;
       coinscol.Text = "Conis=" + coins.ToString();
       y = r2.Next(155, 280);
       z = r2.Next(0, 378);
       coin3.Location = new Point(y, z);
   }
   if (car.Bounds.IntersectsWith(coin4.Bounds))
   {
       coins++;
       coinscol.Text = "Conis=" + coins.ToString();
       y = r2.Next(155, 280);
       z = r2.Next(0, 378);
       coin4.Location = new Point(y, z);
   }
            if (car.Bounds.IntersectsWith(flag.Bounds))
            {
                coins+=10;
                coinscol.Text = "Conis=" + coins.ToString();
                y = r2.Next(0, 350);
                z = r2.Next(0, 378);
                coin1.Location = new Point(y, z);
            }
        }
        void flagc(int speed)
        {
            int a,b;
            
            if (flag.Top >= 500)
            {
                a = r2.Next(0, 350);
                b = r2.Next(0, 378);
                coin1.Location = new Point(a, b);
            }
            else
            { coin1.Top += speed; }






        }
void gameover()
{
   Form2 obj = new Form2();

   if (car.Bounds.IntersectsWith(enemy1.Bounds))
   {
       timer1.Enabled = false;
       this.Hide();
       obj.Show();
   }
   if (car.Bounds.IntersectsWith(enemy2.Bounds))
   {
       timer1.Enabled = false;
       this.Hide();
        obj.Show();

   }
   if (car.Bounds.IntersectsWith(enemy3.Bounds))
   {
       timer1.Enabled = false;
       this.Hide();
       obj.Show();

   }
   if (car.Bounds.IntersectsWith(enemy4.Bounds))
   {
       timer1.Enabled = false;
       this.Hide();
       obj.Show();

   }
   if (car.Bounds.IntersectsWith(enemy5.Bounds))
   {
       timer1.Enabled = false;
       this.Hide();
       obj.Show();


   }
}
    }
}
