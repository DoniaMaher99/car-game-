﻿
namespace car_game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.coinscol = new System.Windows.Forms.Label();
            this.flag = new System.Windows.Forms.PictureBox();
            this.coin4 = new System.Windows.Forms.PictureBox();
            this.coin3 = new System.Windows.Forms.PictureBox();
            this.coin2 = new System.Windows.Forms.PictureBox();
            this.coin1 = new System.Windows.Forms.PictureBox();
            this.enemy5 = new System.Windows.Forms.PictureBox();
            this.enemy4 = new System.Windows.Forms.PictureBox();
            this.enemy3 = new System.Windows.Forms.PictureBox();
            this.enemy2 = new System.Windows.Forms.PictureBox();
            this.enemy1 = new System.Windows.Forms.PictureBox();
            this.car = new System.Windows.Forms.PictureBox();
            this.rl5 = new System.Windows.Forms.PictureBox();
            this.rl4 = new System.Windows.Forms.PictureBox();
            this.rl3 = new System.Windows.Forms.PictureBox();
            this.rl2 = new System.Windows.Forms.PictureBox();
            this.rl1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.flag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.car)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // coinscol
            // 
            this.coinscol.AutoSize = true;
            this.coinscol.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coinscol.Location = new System.Drawing.Point(-3, -4);
            this.coinscol.Name = "coinscol";
            this.coinscol.Size = new System.Drawing.Size(113, 29);
            this.coinscol.TabIndex = 22;
            this.coinscol.Text = "Coins=0";
            // 
            // flag
            // 
            this.flag.Image = global::car_game.Properties.Resources.flag;
            this.flag.Location = new System.Drawing.Point(101, 46);
            this.flag.Name = "flag";
            this.flag.Size = new System.Drawing.Size(44, 53);
            this.flag.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.flag.TabIndex = 23;
            this.flag.TabStop = false;
            // 
            // coin4
            // 
            this.coin4.Image = global::car_game.Properties.Resources.coin;
            this.coin4.Location = new System.Drawing.Point(316, 223);
            this.coin4.Name = "coin4";
            this.coin4.Size = new System.Drawing.Size(32, 31);
            this.coin4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin4.TabIndex = 21;
            this.coin4.TabStop = false;
            // 
            // coin3
            // 
            this.coin3.Image = global::car_game.Properties.Resources.coin;
            this.coin3.Location = new System.Drawing.Point(246, 46);
            this.coin3.Name = "coin3";
            this.coin3.Size = new System.Drawing.Size(32, 31);
            this.coin3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin3.TabIndex = 20;
            this.coin3.TabStop = false;
            // 
            // coin2
            // 
            this.coin2.Image = global::car_game.Properties.Resources.coin;
            this.coin2.Location = new System.Drawing.Point(141, 302);
            this.coin2.Name = "coin2";
            this.coin2.Size = new System.Drawing.Size(32, 31);
            this.coin2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin2.TabIndex = 19;
            this.coin2.TabStop = false;
            // 
            // coin1
            // 
            this.coin1.Image = global::car_game.Properties.Resources.coin;
            this.coin1.Location = new System.Drawing.Point(49, 114);
            this.coin1.Name = "coin1";
            this.coin1.Size = new System.Drawing.Size(32, 31);
            this.coin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin1.TabIndex = 18;
            this.coin1.TabStop = false;
            // 
            // enemy5
            // 
            this.enemy5.Image = global::car_game.Properties.Resources.enemy_car1;
            this.enemy5.Location = new System.Drawing.Point(327, 12);
            this.enemy5.Name = "enemy5";
            this.enemy5.Size = new System.Drawing.Size(27, 64);
            this.enemy5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy5.TabIndex = 17;
            this.enemy5.TabStop = false;
            // 
            // enemy4
            // 
            this.enemy4.Image = global::car_game.Properties.Resources.enemy_car1;
            this.enemy4.Location = new System.Drawing.Point(66, 239);
            this.enemy4.Name = "enemy4";
            this.enemy4.Size = new System.Drawing.Size(27, 64);
            this.enemy4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy4.TabIndex = 16;
            this.enemy4.TabStop = false;
            // 
            // enemy3
            // 
            this.enemy3.Image = global::car_game.Properties.Resources.enemy_car1;
            this.enemy3.Location = new System.Drawing.Point(16, -4);
            this.enemy3.Name = "enemy3";
            this.enemy3.Size = new System.Drawing.Size(27, 64);
            this.enemy3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy3.TabIndex = 15;
            this.enemy3.TabStop = false;
            // 
            // enemy2
            // 
            this.enemy2.Image = global::car_game.Properties.Resources.enemy_car1;
            this.enemy2.Location = new System.Drawing.Point(272, 363);
            this.enemy2.Name = "enemy2";
            this.enemy2.Size = new System.Drawing.Size(27, 64);
            this.enemy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy2.TabIndex = 14;
            this.enemy2.TabStop = false;
            // 
            // enemy1
            // 
            this.enemy1.Image = global::car_game.Properties.Resources.enemy_car1;
            this.enemy1.Location = new System.Drawing.Point(215, 135);
            this.enemy1.Name = "enemy1";
            this.enemy1.Size = new System.Drawing.Size(27, 64);
            this.enemy1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy1.TabIndex = 13;
            this.enemy1.TabStop = false;
            // 
            // car
            // 
            this.car.Image = global::car_game.Properties.Resources.car;
            this.car.Location = new System.Drawing.Point(170, 369);
            this.car.Name = "car";
            this.car.Size = new System.Drawing.Size(37, 72);
            this.car.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.car.TabIndex = 12;
            this.car.TabStop = false;
            // 
            // rl5
            // 
            this.rl5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rl5.Location = new System.Drawing.Point(179, 419);
            this.rl5.Name = "rl5";
            this.rl5.Size = new System.Drawing.Size(15, 110);
            this.rl5.TabIndex = 11;
            this.rl5.TabStop = false;
            // 
            // rl4
            // 
            this.rl4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rl4.Location = new System.Drawing.Point(179, 302);
            this.rl4.Name = "rl4";
            this.rl4.Size = new System.Drawing.Size(15, 110);
            this.rl4.TabIndex = 10;
            this.rl4.TabStop = false;
            // 
            // rl3
            // 
            this.rl3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rl3.Location = new System.Drawing.Point(179, 163);
            this.rl3.Name = "rl3";
            this.rl3.Size = new System.Drawing.Size(15, 110);
            this.rl3.TabIndex = 9;
            this.rl3.TabStop = false;
            // 
            // rl2
            // 
            this.rl2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rl2.Location = new System.Drawing.Point(179, 37);
            this.rl2.Name = "rl2";
            this.rl2.Size = new System.Drawing.Size(15, 110);
            this.rl2.TabIndex = 8;
            this.rl2.TabStop = false;
            // 
            // rl1
            // 
            this.rl1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rl1.Location = new System.Drawing.Point(179, -88);
            this.rl1.Name = "rl1";
            this.rl1.Size = new System.Drawing.Size(15, 110);
            this.rl1.TabIndex = 7;
            this.rl1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox2.Location = new System.Drawing.Point(2, -14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(8, 488);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Location = new System.Drawing.Point(372, -14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(8, 488);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(382, 453);
            this.Controls.Add(this.flag);
            this.Controls.Add(this.coinscol);
            this.Controls.Add(this.coin4);
            this.Controls.Add(this.coin3);
            this.Controls.Add(this.coin2);
            this.Controls.Add(this.coin1);
            this.Controls.Add(this.enemy5);
            this.Controls.Add(this.enemy4);
            this.Controls.Add(this.enemy3);
            this.Controls.Add(this.enemy2);
            this.Controls.Add(this.enemy1);
            this.Controls.Add(this.car);
            this.Controls.Add(this.rl5);
            this.Controls.Add(this.rl4);
            this.Controls.Add(this.rl3);
            this.Controls.Add(this.rl2);
            this.Controls.Add(this.rl1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.flag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.car)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox rl1;
        private System.Windows.Forms.PictureBox rl2;
        private System.Windows.Forms.PictureBox rl3;
        private System.Windows.Forms.PictureBox rl4;
        private System.Windows.Forms.PictureBox rl5;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox car;
        private System.Windows.Forms.PictureBox enemy1;
        private System.Windows.Forms.PictureBox enemy2;
        private System.Windows.Forms.PictureBox enemy3;
        private System.Windows.Forms.PictureBox enemy4;
        private System.Windows.Forms.PictureBox enemy5;
        private System.Windows.Forms.PictureBox coin1;
        private System.Windows.Forms.PictureBox coin2;
        private System.Windows.Forms.PictureBox coin3;
        private System.Windows.Forms.PictureBox coin4;
        private System.Windows.Forms.Label coinscol;
        private System.Windows.Forms.PictureBox flag;
    }
}

